import { Component } from '@angular/core';

@Component({
  selector: 'app-tongule-language',
  templateUrl: './tongule-language.component.html',
  styleUrl: './tongule-language.component.css'
})
export class TonguleLanguageComponent {

}
