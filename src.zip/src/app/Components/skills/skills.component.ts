import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputformdataService } from '../../inputformdata.service';
@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrl: './skills.component.css',
})
export class SkillsComponent implements OnInit {
  public formdata: any;
  shippeddata: any;
  finalvalue: any;
  public valueChangesSubscription: any;
  constructor(private InputformdataService: InputformdataService) {}

  UserInfo = new FormGroup({
    SkillsName: new FormControl('', [Validators.required]),
  });
  userdetail() {
    console.log(this.UserInfo.value);
    this.formdata = this.UserInfo.value;
    console.log(this.formdata);
    this.InputformdataService.getSkillsData(this.formdata);
  }

  ngOnInit() {}
  //
  get SkillsName() {
    return this.UserInfo.get('SkillsName');
  }
}
