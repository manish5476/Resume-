import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputformdataService } from '../../inputformdata.service';
@Component({
  selector: 'app-achievement',
  templateUrl: './achievement.component.html',
  styleUrl: './achievement.component.css',
})
export class AchievementComponent implements OnInit {
  public formdata: any;
  shippeddata: any;
  finalvalue: any;

  constructor(private InputformdataService: InputformdataService) {}

  public valueChangesSubscription: any;
  UserInfo = new FormGroup({
    CertificateName: new FormControl('', [Validators.required]),
    CertificateLink: new FormControl('', [Validators.required]),
  });
  userdetail() {
    console.log(this.UserInfo.value);
    this.formdata = this.UserInfo.value;
    console.log(this.formdata);
    this.InputformdataService.getAchievementsData(this.formdata);
  }

  ngOnInit() {}
  //
  get CertificateName() {
    return this.UserInfo.get('CertificateName');
  }
  get CertificateLink() {
    return this.UserInfo.get('CertificateLink');
  }
}
