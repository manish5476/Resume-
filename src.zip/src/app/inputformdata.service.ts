import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class InputformdataService {
  constructor() {}

  yourself: any;
  achievent: any;
  education: any;
  professionalExperience: any;
  projects: any;
  skills: any;
  //

  // yourself data service

  GetYourselfData(data: any) {
    this.yourself = data;
    console.log(this.yourself);
  }
  setYourselfData() {
    console.log(this.yourself);
    return this.yourself;
  }

  // Achievements data service
  getAchievementsData(data: any) {
    this.achievent = data;
    console.log(this.achievent);
  }
  setAchievementsData() {
    console.log(this.achievent);
    return this.achievent;
  }
  // education data service
  getEducationData(data: any) {
    this.education = data;
    console.log(this.education);
  }
  setEducationData() {
    console.log(this.education);
    return this.education;
  }
  // professionalExperience data service
  getProfessionalExperienceData(data: any) {
    this.professionalExperience = data;
    console.log(this.professionalExperience);
  }
  setProfessionalExperienceData() {
    console.log(this.professionalExperience);
    return this.professionalExperience;
  }
  // projects data service
  getProjectsData(data: any) {
    this.projects = data;
    console.log(this.projects);
  }
  setProjectsData() {
    console.log(this.projects);
    return this.projects;
  }
  // Skills data service
  getSkillsData(data: any) {
    this.skills = data;
    console.log(this.skills);
  }
  setSkillsData() {
    console.log(this.skills);
    return this.skills;
  }
}
