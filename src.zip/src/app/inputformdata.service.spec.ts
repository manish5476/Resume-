import { TestBed } from '@angular/core/testing';

import { InputformdataService } from './inputformdata.service';

describe('InputformdataService', () => {
  let service: InputformdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InputformdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
